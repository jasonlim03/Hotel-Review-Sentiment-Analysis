#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <stdexcept>
#include <chrono> // For measuring time
#include <cmath> // for sqrt()
#include "DynamicArray.hpp" // Assuming your custom DynamicArray class exists
#include "WordList.hpp"     // Assuming your custom WordList class exists
#include "WordFrequency.hpp" // Include the custom WordFrequency class

using namespace std;
using namespace std::chrono;

void toLowercase(string& str) {
    for (char& c : str) {
        c = tolower(c);
    }
}

// Manual splitting of CSV
void splitLine(const string& line, string& review, string& ratingStr) {
    size_t pos = line.find_last_of(',');
    if (pos != string::npos) {
        review = line.substr(0, pos);
        ratingStr = line.substr(pos + 1);
    }
}

// Jump search function for checking if a word exists in the DynamicArray
bool jumpSearch(const DynamicArray<string>& wordArray, const string& word) {
    size_t n = wordArray.getSize();

    if (n == 0) {
        return false; // Empty array, word not found
    }

    // Calculate the optimal jump step (sqrt of the array size)
    size_t step = sqrt(n);
    size_t prev = 0;

    // Jump ahead by step size until we find an interval where the element may exist
    while (wordArray.get(min(step, n) - 1) < word) {
        prev = step;
        step += sqrt(n);
        if (prev >= n) {
            return false; // Word not found
        }
    }

    // Perform a linear search in the block defined by [prev, step)
    for (size_t i = prev; i < min(step, n); ++i) {
        if (wordArray.get(i) == word) {
            return true; // Word found
        }
    }

    return false; // Word not found
}

// Binary search for a word in a sorted DynamicArray
bool binarySearch(const DynamicArray<string>& wordArray, const string& word) {
    int left = 0;
    int right = wordArray.getSize() - 1;

    while (left <= right) {
        int middle = left + (right - left) / 2;
        if (wordArray.get(middle) == word) {
            return true; // Word found
        }
        if (wordArray.get(middle) < word) {
            left = middle + 1; // Search the right half
        }
        else {
            right = middle - 1; // Search the left half
        }
    }
    return false; // Word not found
}

// Function to collect sentiment words using the chosen search method
void collectSentimentWords(const string& cleanedReview,
    const DynamicArray<string>& positiveWords,
    const DynamicArray<string>& negativeWords,
    int& positiveCount,
    int& negativeCount,
    DynamicArray<string>& collectedPositiveWords,
    DynamicArray<string>& collectedNegativeWords,
    int searchChoice) {

    string word;
    size_t start = 0;

    // Tokenize the cleanedReview string to separate words
    while (start < cleanedReview.length()) {
        // Find the next space or punctuation
        size_t end = cleanedReview.find_first_of(" ,.!?;:", start);

        // If no more spaces, take the rest of the string
        if (end == string::npos) {
            end = cleanedReview.length();
        }

        // Extract the word
        word = cleanedReview.substr(start, end - start);

        // Check for hyphenated words (e.g., "non-existent")
        if (word.find('-') != string::npos) {
            // Add the hyphenated word directly
            if ((searchChoice == 1 && binarySearch(negativeWords, word)) ||
                (searchChoice == 2 && jumpSearch(negativeWords, word))) {
                bool alreadyExists = false;
                for (size_t i = 0; i < collectedNegativeWords.getSize(); ++i) {
                    if (collectedNegativeWords.get(i) == word) {
                        alreadyExists = true;
                        break;
                    }
                }
                if (!alreadyExists) {
                    negativeCount++;
                    collectedNegativeWords.push_back(word);
                }
            }
        }
        else {
            // Normal word processing
            bool isPositive = (searchChoice == 1 && binarySearch(positiveWords, word)) ||
                (searchChoice == 2 && jumpSearch(positiveWords, word));

            bool isNegative = (searchChoice == 1 && binarySearch(negativeWords, word)) ||
                (searchChoice == 2 && jumpSearch(negativeWords, word));

            // Only add unique words to the collected arrays
            if (isPositive) {
                bool alreadyExists = false;
                for (size_t i = 0; i < collectedPositiveWords.getSize(); ++i) {
                    if (collectedPositiveWords.get(i) == word) {
                        alreadyExists = true;
                        break;
                    }
                }
                if (!alreadyExists) {
                    positiveCount++;
                    collectedPositiveWords.push_back(word);
                }
            }

            if (isNegative) {
                bool alreadyExists = false;
                for (size_t i = 0; i < collectedNegativeWords.getSize(); ++i) {
                    if (collectedNegativeWords.get(i) == word) {
                        alreadyExists = true;
                        break;
                    }
                }
                if (!alreadyExists) {
                    negativeCount++;
                    collectedNegativeWords.push_back(word);
                }
            }
        }

        start = end + 1; // Move to the next word
    }
}

void printCollectedWords(const DynamicArray<string>& collectedWords, const string& type) {
    std::cout << type << " Words = " << collectedWords.getSize() << ":\n";
    for (size_t i = 0; i < collectedWords.getSize(); ++i) {
        std::cout << "-" << collectedWords.get(i) << "\n";
    }
    cout << endl;
}


// Function to calculate the normalized sentiment score (1-5 scale)
double calculateSentimentScore(int positiveCount, int negativeCount) {
    int rawScore = positiveCount - negativeCount;
    int N = positiveCount + negativeCount; // Total number of positive and negative words

    if (N == 0) {
        return 3.0; // Neutral score if no words are found
    }

    int minRawScore = -N;
    int maxRawScore = N;

    // Normalized score formula
    double normalizedScore = (rawScore - minRawScore) / static_cast<double>(maxRawScore - minRawScore);
    double sentimentScore = 1 + (4 * normalizedScore);

    return sentimentScore;
}

// Function to load words from a file
void loadWords(const string& filename, DynamicArray<string>& wordArray) { // Correct template usage
    auto start = chrono::high_resolution_clock::now();

    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to open file: " << filename << endl;
        return;
    }

    string word;
    while (file >> word) {
        wordArray.push_back(word);
        cout << "Loaded word: " << word << endl; // Print loaded words
    }

    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end - start;
    cout << "Time taken to load words from " << filename << ": " << elapsed.count() << " seconds.\n";
}

int main() {
    auto mainStart = chrono::high_resolution_clock::now();
    DynamicArray<string> positiveWords; // Correct template usage
    DynamicArray<string> negativeWords; // Correct template usage

    cout << "Loading positive words...\n";
    loadWords("positive-words.txt", positiveWords);

    cout << "Loading negative words...\n";
    loadWords("negative-words.txt", negativeWords);

    ifstream reviewFile("tripadvisor_hotel_reviews.csv");
    if (!reviewFile.is_open()) {
        cerr << "Failed to open review file." << endl;
        return 1; // Exit if the file could not be opened
    }

    string line;
    int totalPositiveWords = 0, totalNegativeWords = 0, totalReviews = 0;
    int totalMatchingReviews = 0, totalUnmatchingReviews = 0; // New counters
    WordFrequency wordFrequency; // Use the custom word frequency class

    const int rCount = 20493;

    bool keepSearching = true;
    int searchChoice;

    // New loop for search method selection
    while (keepSearching) {
        // Prompt the user for the search method
        cout << "Choose searching method:\n";
        cout << "1. Binary Search\n";
        cout << "2. Jump Search\n";
        cout << "3. Exit\n";
        cout << "Enter your choice (1, 2, or 3): ";
        cin >> searchChoice;

        if (searchChoice == 3) {
            keepSearching = false; // Exit the loop
            continue;
        }

        // Validate the choice
        if (searchChoice != 1 && searchChoice != 2) {
            cerr << "Invalid choice! Please enter 1, 2, or 3." << endl;
            continue;
        }

        // Reset the file pointer to the beginning of the file
        reviewFile.clear(); // Clear any error flags
        reviewFile.seekg(0); // Move the file pointer to the beginning

        // Reset counters for the new search round
        totalPositiveWords = 0;
        totalNegativeWords = 0;
        totalReviews = 0;


        // Start the timer
        auto start = high_resolution_clock::now();

        while (totalReviews < rCount && getline(reviewFile, line)) {
            string review;
            string ratingStr;

            // Manually split the line without std::stringstream
            splitLine(line, review, ratingStr);

            int userRating;
            try {
                userRating = stoi(ratingStr); // Convert rating string to integer
            }
            catch (const invalid_argument&) {
                cerr << "Invalid rating format: " << ratingStr << endl;
                continue; // Skip this line if rating conversion fails
            }

            toLowercase(review); // Convert to lowercase for better matching
            cout << "Analyzing review: " << review << " | User Rating: " << userRating << endl;

            int positiveCount = 0, negativeCount = 0;
            DynamicArray<string> collectedPositiveWords; // Correct template usage
            DynamicArray<string> collectedNegativeWords; // Correct template usage

            // Collect sentiment words using the selected search method
            collectSentimentWords(review, positiveWords, negativeWords,
                positiveCount, negativeCount,
                collectedPositiveWords, collectedNegativeWords,
                searchChoice);

            printCollectedWords(collectedPositiveWords, "Positive");
            printCollectedWords(collectedNegativeWords, "Negative");

            // Add counts to the WordFrequency object
            for (size_t k = 0; k < collectedPositiveWords.getSize(); ++k) {
                wordFrequency.addWord(collectedPositiveWords.get(k));
            }

            for (size_t k = 0; k < collectedNegativeWords.getSize(); ++k) {
                wordFrequency.addWord(collectedNegativeWords.get(k));
            }

            // Calculate the normalized sentiment score
            double sentimentScore = calculateSentimentScore(positiveCount, negativeCount);
            cout << "Sentiment score (1 - 5): " << sentimentScore << endl;

            // Compare the sentiment score with the user rating
            if ((sentimentScore > 3 && userRating < 3) || (sentimentScore < 3 && userRating > 3)) {
                cout << "User's subjective evaluation does not match the sentiment score.\n" << endl;
                totalUnmatchingReviews++; // Increment unmatching review counter
            }
            else {
                cout << "User's subjective evaluation matches the sentiment score.\n" << endl;
                totalMatchingReviews++; // Increment matching review counter
            }

            // Stop the timer
            auto stop = high_resolution_clock::now();

            // Calculate the duration and print the execution time in seconds
            auto duration = duration_cast<milliseconds>(stop - start);
            cout << "Time execution for this searching algorithm: " << duration.count() << " milliseconds." << "\n" << endl;

            // Update overall counts
            totalPositiveWords += positiveCount;
            totalNegativeWords += negativeCount;
            totalReviews++;
        }
    }

    // Calculate evaluation accuracy
    double accuracy = 0;
    if (totalMatchingReviews + totalUnmatchingReviews > 0) {
        accuracy = (static_cast<double>(totalMatchingReviews) /
            (totalMatchingReviews + totalUnmatchingReviews)) * 100;
    }

    // Print overall sentiment statistics
    cout << "-----------------------------------\n";
    cout << "Review Analysis Summary:\n";
    cout << "-----------------------------------\n";
    cout << "Total Reviews: " << totalReviews << "\n";
    cout << "Total Positive Words: " << totalPositiveWords << "\n";
    cout << "Total Negative Words: " << totalNegativeWords << "\n";
    cout << "Total Matching Reviews: " << totalMatchingReviews << "\n"; // Display matching reviews
    cout << "Total Unmatching Reviews: " << totalUnmatchingReviews << "\n"; // Display unmatching reviews
    cout << "Overall Evaluation Accuracy: " << accuracy << "%\n"; // Display evaluation accuracy
    cout << "-----------------------------------\n";

    int sortChoice;
    bool keepSorting = true;
    bool frequenciesDisplayed = false; // Track if frequencies have been displayed

    while (keepSorting) {
        // Prompt the user for sort selection
        cout << "Choose sorting method:\n";
        cout << "1. Merge Sort\n";
        cout << "2. Quick Sort\n";
        cout << "3. Exit\n";
        cout << "Enter your choice (1, 2, or 3): ";
        cin >> sortChoice;

        if (sortChoice == 1) {
            // Merge Sort
            auto mStart = chrono::high_resolution_clock::now();
            wordFrequency.mergeSortFrequencies();
            auto mEnd = chrono::high_resolution_clock::now();
            chrono::duration<double> mergeDuration = mEnd - mStart;

            // Print word frequencies after sorting
            cout << "Frequency of each word used in overall reviews (after Merge Sort):\n";
            for (size_t i = 0; i < wordFrequency.getSize(); ++i) {
                cout << wordFrequency.getWord(i) << ": " << wordFrequency.getCount(wordFrequency.getWord(i)) << endl;
            }
            cout << "Merge sort execution time: " << mergeDuration.count() << " seconds" << endl;
        }
        else if (sortChoice == 2) {
            // Quick Sort
            auto qStart = chrono::high_resolution_clock::now();
            wordFrequency.quickSortFrequencies();
            auto qEnd = chrono::high_resolution_clock::now();
            chrono::duration<double> quickDuration = qEnd - qStart;

            // Print word frequencies after sorting
            cout << "Frequency of each word used in overall reviews (after Quick Sort):\n";
            for (size_t i = 0; i < wordFrequency.getSize(); ++i) {
                cout << wordFrequency.getWord(i) << ": " << wordFrequency.getCount(wordFrequency.getWord(i)) << endl;
            }
            cout << "Quick sort execution time: " << quickDuration.count() << " seconds" << endl;
        }
        else if (sortChoice == 3) {
            keepSorting = false; // Exit the loop
            continue; // Skip further processing if exiting
        }
        else {
            cerr << "Invalid choice! Please enter 1, 2, or 3." << endl;
            continue; // Re-prompt the user if the input is invalid
        }
    }

    int maxFrequency = wordFrequency.findMaxFrequency();
    cout << "Maximum Frequency: " << maxFrequency << endl;

    int minFrequency = wordFrequency.findMinFrequency();
    cout << "Minimum Frequency: " << minFrequency << endl;

    auto mainEnd = chrono::high_resolution_clock::now();
    chrono::duration<double> overallElapsed = mainEnd - mainStart;
    cout << "Total time taken for overall analysis: " << overallElapsed.count() << " seconds.\n";

    // Reset the word frequencies after exiting the loop
    wordFrequency.resetFrequencies();

    return 0; // Return success
}